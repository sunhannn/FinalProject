package com.ggul.zip.review;

public class ReviewVO {
	private int review_num;
	private int review_lesson_num;
	private String review_cont;
	private String review_writer;
	private int review_sugar;
	private String review_date;

	public int getReview_num() {
		return review_num;
	}

	public void setReview_num(int review_num) {
		this.review_num = review_num;
	}

	public int getReview_lesson_num() {
		return review_lesson_num;
	}

	public void setReview_lesson_num(int review_lesson_num) {
		this.review_lesson_num = review_lesson_num;
	}

	public String getReview_cont() {
		return review_cont;
	}

	public void setReview_cont(String review_cont) {
		this.review_cont = review_cont;
	}

	public String getReview_writer() {
		return review_writer;
	}

	public void setReview_writer(String review_writer) {
		this.review_writer = review_writer;
	}

	public int getReview_sugar() {
		return review_sugar;
	}

	public void setReview_sugar(int review_sugar) {
		this.review_sugar = review_sugar;
	}

	public String getReview_date() {
		return review_date;
	}

	public void setReview_date(String review_date) {
		this.review_date = review_date;
	}

}
