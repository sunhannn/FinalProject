package com.ggul.zip.review;

public interface ReviewService {

	int ReviewInsert(ReviewVO reviewVO);

}
