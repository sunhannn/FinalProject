package com.ggul.zip.review;

import com.ggul.zip.lesson.ReviewVO;

public interface ReviewService {

	int reviewInsert(ReviewVO reviewVO);

}
