package com.ggul.zip.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ggul.zip.lesson.LessonVO;
import com.ggul.zip.main.MainService;
import com.ggul.zip.search.SearchService;
import com.ggul.zip.user.UserVO;

@Controller
public class MainController {
	
	@Autowired
	private SearchService searchService;
	
	@Autowired
	private MainService mainService;
	
	
	@RequestMapping(value = { "/", "/index"}, method = RequestMethod.GET)
	public String home(LessonVO vo, Model model, HttpSession session, UserVO uvo) {
		String user_id = session.getAttribute("user_id") != null ? session.getAttribute("user_id").toString() : "";
		vo.setUser_id(user_id);
		
		model.addAttribute("mainRecm", mainService.getMainRecm(vo));
		model.addAttribute("mainPop", mainService.getMainPop(vo));
		model.addAttribute("mainNew", mainService.getMainNew(vo));
		return "index";
	}
	
	@RequestMapping(value="/cateSearch", method = RequestMethod.GET)
	public String getSearchCate(LessonVO vo, Model model) {
		model.addAttribute("searchAll", searchService.getSearchCate(vo));
		return "search/searchAll";
	}
	
	@RequestMapping(value="/allSearch", method = RequestMethod.GET)
	public String getSearchAll(LessonVO vo, Model model) {
		model.addAttribute("searchAll", searchService.getSearchAll(vo));
		return "search/searchAll";
	}
	
	@RequestMapping(value= "/selectPartSearch", method = RequestMethod.POST)
	public String getSearch(LessonVO vo, Model model){
		model.addAttribute("searchAll", searchService.getPartSearchList(vo));
		return "search/searchAll";
	}
	
	@RequestMapping(value= "/selectSearch", method = RequestMethod.POST)
	public String getSearchList(LessonVO vo, Model model){
		model.addAttribute("searchAll", searchService.getSearchList(vo));
		return "search/searchAll";
	}

	
}
